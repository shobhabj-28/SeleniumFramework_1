package com.ibm.pages;

public class UserPage {

}
